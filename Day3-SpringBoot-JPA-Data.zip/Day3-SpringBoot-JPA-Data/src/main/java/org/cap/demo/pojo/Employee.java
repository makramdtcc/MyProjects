package org.cap.demo.pojo;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQuery;



@NamedQuery(name="findById",query="select emp from Employee emp where empId>3")
//@NamedNativeQuery(name = "sqlLikeQuery", query="SELECT * FROM Employees  WHERE LOWER(firstname) LIKE LOWER(CONCAT('%',:searchTerm, '%'))")

//Direct SQL query
@NamedNativeQueries({
	@NamedNativeQuery(name="sqlQuery",query="select * from employee where salary>55000"),
	@NamedNativeQuery(name="sqlLikeQuery",query="select * from employee where first_name like 'J%' order by salary desc")
})
@Entity
public class Employee implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	private int empId;
	private String firstName;
	private String lastName;
	private double salary;
	
	
	public Employee() {
		
	}
	public Employee(int empId, String firstName, String lastName, double salary) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", salary=" + salary
				+ "]";
	}
	
	

}
